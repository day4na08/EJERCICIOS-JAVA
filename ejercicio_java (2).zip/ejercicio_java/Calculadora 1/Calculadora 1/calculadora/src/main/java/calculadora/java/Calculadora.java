package calculadora.java;
import java.util.Scanner;
import java.util.Stack;

public class Calculadora {

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Ingrese una expresión matemática: ");
            String expresion = scanner.nextLine();

            try {
                double resultado = evaluarExpresion(expresion);
                System.out.println("El resultado es: " + resultado);
            } catch (ArithmeticException e) {
                System.out.println("Error matemático: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    public static double evaluarExpresion(String expresion) {
        Stack<Double> numeros = new Stack<>();
        Stack<Character> operadores = new Stack<>();

        for (int i = 0; i < expresion.length(); i++) {
            char caracter = expresion.charAt(i);

            if (caracter == ' ') {
                continue; // Saltar espacios en blanco
            } else if (Character.isDigit(caracter) || caracter == '.') {
                StringBuilder numero = new StringBuilder();
                while (i < expresion.length() && (Character.isDigit(expresion.charAt(i)) || expresion.charAt(i) == '.')) {
                    numero.append(expresion.charAt(i++));
                }
                i--; // Retroceder una posición, ya que el bucle for incrementará i
                numeros.push(Double.parseDouble(numero.toString()));
            } else if (caracter == '(') {
                operadores.push(caracter);
            } else if (caracter == ')') {
                while (operadores.peek() != '(') {
                    numeros.push(aplicarOperacion(operadores.pop(), numeros.pop(), numeros.pop()));
                }
                operadores.pop(); // Sacar el '('
            } else if (esOperador(caracter)) {
                while (!operadores.isEmpty() && precedencia(operadores.peek()) >= precedencia(caracter)) {
                    numeros.push(aplicarOperacion(operadores.pop(), numeros.pop(), numeros.pop()));
                }
                operadores.push(caracter);
            } else {
                throw new IllegalArgumentException("Carácter no válido en la expresión: " + caracter);
            }
        }

        while (!operadores.isEmpty()) {
            numeros.push(aplicarOperacion(operadores.pop(), numeros.pop(), numeros.pop()));
        }

        return numeros.pop();
    }

    public static boolean esOperador(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/';
    }

    public static int precedencia(char operador) {
        if (operador == '+' || operador == '-') {
            return 1;
        } else if (operador == '*' || operador == '/') {
            return 2;
        }
        return 0;
    }

    public static double aplicarOperacion(char operador, double b, double a) {
        switch (operador) {
            case '+':
                return a + b;
            case '-':
                return a - b;
            case '*':
                return a * b;
            case '/':
                if (b == 0) {
                    throw new ArithmeticException("División por cero");
                }
                return a / b;
        }
        return 0;
    }
}
